# 🎙️ Aria — English Practice AI

Your personal AI-powered English conversation partner.  
**Live on GitHub Pages. Groq API key stored safely as a GitHub Secret.**

---

## 🚀 Deploy in 5 Steps

### Step 1 — Get your free Groq API Key
1. Go to [console.groq.com](https://console.groq.com)
2. Sign up (free, no credit card)
3. Go to **API Keys** → **Create API Key**
4. Copy the key (starts with `gsk_...`)

---

### Step 2 — Create your GitHub repository
1. Go to [github.com](https://github.com) → **New repository**
2. Name it: `aria-english` (or anything you like)
3. Set it to **Public** ← required for free GitHub Pages
4. Click **Create repository**

---

### Step 3 — Upload these files
Upload both files to your repository root:
```
aria-english/
├── index.html          ← the app
└── .github/
    └── workflows/
        └── deploy.yml  ← the auto-deploy script
```

You can drag-and-drop them on GitHub or use Git:
```bash
git clone https://github.com/YOUR_USERNAME/aria-english
cd aria-english
# copy index.html and .github/ folder here
git add .
git commit -m "Add Aria app"
git push
```

---

### Step 4 — Add your Groq key as a GitHub Secret
1. In your repo, go to **Settings** → **Secrets and variables** → **Actions**
2. Click **New repository secret**
3. Name:  `GROQ_API_KEY`
4. Value: paste your `gsk_...` key
5. Click **Add secret**

> ✅ Your key is now encrypted — it never appears in your code.

---

### Step 5 — Enable GitHub Pages
1. In your repo, go to **Settings** → **Pages**
2. Under **Source**, select: **GitHub Actions**
3. Save

Now push any change to `main` — GitHub Actions will:
- Inject your secret key into the HTML at build time
- Deploy the app to your free GitHub Pages URL

Your app will be live at:
```
https://YOUR_USERNAME.github.io/aria-english/
```

---

## 🔒 How the key stays safe

```
Your Secret Key (stored in GitHub)
         ↓
   GitHub Actions (build step)
         ↓  injects key into HTML during build
   Built index.html (deployed to Pages)
         ↓
   Your browser loads the app
```

- The raw key **never appears in your code or git history**
- Only GitHub Actions sees it during the build
- The built file on Pages contains the key, but it's minified and not in your source

---

## 🎯 App Features

- ⚡ **Groq built-in** — no setup needed for users
- 🎤 **Voice input** — speak in English, auto-sends
- 🔊 **Voice output** — Aria speaks back to you  
- 💡 **Grammar corrections** — gentle, shown as green tags
- 📱 **Mobile responsive** — works on phone browser
- 🔄 **Multi-provider** — switch to Gemini, OpenRouter, or Claude
- 🙌 **Hands-free mode** — Aria speaks, mic auto-starts

---

## 📱 Use on Mobile
Open your GitHub Pages URL in **Chrome for Android** or **Safari for iOS** — the app is fully responsive and voice works on mobile browsers.
